﻿var items = [
    "Apples",
    "Apricots",
    "Aubergines",
    "Bananas",
    "Beetroot",
    "Carrots",
    "Cornflakes",
    "Courgettes",
    "Chives",
    "Fennel",
    "Milk",
    "Potatoes",
    "Salt",
    "Strawberries",
    "Sugar"
];

var chosenItems = {};
var newList= {
    name,
    dateCreated:new Date()
}

var shoppingLists = [];
var shoppingItems = [];

$(document).on("pageinit", function (event) {
    initApp();
    $("#submit").on('tap', function(e) {
        e.stopImmediatePropagation();
        e.preventDefault();
        var title = $("#title").val();
        if (title === '')
            alert("List must have a Title");
        var sList = JSON.parse(JSON.stringify(newList));
        sList.name = title;
       if(addNewList(sList))
        {
            $("#title").val('');
            getShoppingLists();
        }
    });
    $("#btnClear").on('tap', function (e) {
        e.stopImmediatePropagation();
        e.preventDefault();
        if(confirm("Clearing Shopping List will also clear all its data. Are you sure?"))
            clearStorage();
    });
    $("#lnkAddItem").on('tap', function() {
        getShoppingItems();
    });
    $("#btnAddItem").on('tap', function(e) {
        e.stopImmediatePropagation();
        e.preventDefault();
        addListItem();
    });

    $(document).on('swipeleft', '.shopping-item', function (e) {
        e.stopImmediatePropagation();
        e.preventDefault();
        var item = $(this);
            var index = item.attr("id");
            if (confirm("Are you sure you want to delete this item?")) {
                deleteShoppingListItem(index);
            };
        });
    $(document).on('swiperight', '.shopping-item', function (e) {
        e.stopImmediatePropagation();
        e.preventDefault();
        var item = $(this);
        var index = item.attr("id");
        MarkShoppingListItemCompleted(index);
    });
    $(document).on('taphold', '.shopping-item', function (e) {
        e.stopImmediatePropagation();
        e.preventDefault();
        var item = $(this);
        var index = item.attr("id");
        unMarkShoppingListItemCompleted(index);
    });
    //$(".shopping-item").each(function (i, e) {
    //    var dis = $(this);
    //    $(document).on('swipeleft', function () {
    //        var index = dis.attr("id");
    //        if (confirm("Are you sure you want to delete this item?")) {
    //            deleteShoppingListItem(index);
    //        };
    //        $.mobile.changePage("#shoppingList");
    //    });
    //});

});
$(document).on("pageshow","#shoppingListPage", function () {
    var currentList = localStorage.getItem("currentList");
    if (!currentList)
        return;
    getList(null,currentList);
});

function initApp() {
    getShoppingLists();
    initShoppingItems();
   
}

function unMarkShoppingListItemCompleted(index) {
    var currentList = localStorage.getItem("currentList");
    if (!currentList)
        return false;
    var existingLists = localStorage.getItem(currentList);
    if (!existingLists)
        return false;
    existingLists = JSON.parse(existingLists);
    var item = existingLists[index];
    if (item.status)
        item.status = false;

    localStorage.setItem(currentList, JSON.stringify(existingLists));
    getList(null, currentList);
    return true;
}

function MarkShoppingListItemCompleted(index) {
    var currentList = localStorage.getItem("currentList");
    if (!currentList)
        return false;
    var existingLists = localStorage.getItem(currentList);
    if (!existingLists)
        return false;
    existingLists = JSON.parse(existingLists);
    var item = existingLists[index];
    if (item.status) 
        return false;
    existingLists[index].status = true;
         
    localStorage.setItem(currentList, JSON.stringify(existingLists));
    getList(null, currentList);
    return true;
}

function deleteShoppingListItem(index) {
    var currentList = localStorage.getItem("currentList");
    if (!currentList)
        return false;
    var existingLists = localStorage.getItem(currentList);
    if (!existingLists)
        return false;
    existingLists = JSON.parse(existingLists);
    var item = existingLists[index];
    if (item.status) /// Should not delete completed item
        return false;
    existingLists.splice(index, 1);
    localStorage.setItem(currentList, JSON.stringify(existingLists));
    getList(null, currentList);
    return true;
}
function addListItem() {
    var currentList =localStorage.getItem("currentList");
    if (!currentList)
        return false;

    var newItem = {
        name,
        quantity: 1,
        status: false,
        dateCreated:new Date()
    }
    var item = $("#itemFilters").val();
    if (item.length === 0)
        return alert("Invalid Item value");
    var quantity = $("#spinQuantity").val();
    if(parseInt(quantity)<=0)
        return alert("Invalid Item Quantity");
     newItem.name = item;
    newItem.quantity = quantity;
    var existingLists = localStorage.getItem(currentList);
    if (!existingLists) {
        var lists = [];
        
        lists.push(newItem);
        localStorage.setItem(currentList, JSON.stringify(lists));
    } else {
        existingLists = JSON.parse(existingLists);
        // Check if item exist in List
        var exists = false;
        for (var i = 0; i < existingLists.length; i++) {
            var listItem = existingLists[i];
            if (listItem.status)  // Don't add to completed item
                continue;
            if (listItem.name.toLowerCase() === item.toLowerCase()) {
                listItem.quantity =parseInt(listItem.quantity)+ parseInt(quantity);
                exists = true;
                    break;
            }
        }

        if (shoppingItems.indexOf(item) === -1) {
            shoppingItems.push(item);
            localStorage.setItem("shoppingItems", JSON.stringify(shoppingItems));
        }
        if (!exists)
            existingLists.push(newItem);

        localStorage.setItem(currentList, JSON.stringify(existingLists));
        getList(null, currentList);
    }
    return true;
};

function getList(index, itemName) {
    if (typeof (index) !== "undefined") {
        var list = shoppingLists[index];
        if (list) {
            getItems(list.name);

        }

    }

    if(itemName){
        getItems(itemName);
    }
    function getItems(v) {
        $("#shopping-header").html(v);
        $('#shoppingListItems').empty();
        var item = localStorage.getItem(v);
        if (item) {
            var shoppingItems = JSON.parse(item);
            var html = '';
            $.each(shoppingItems, function (index, item) {
                var completed = item.status ? "completed" : '';
                html += '<li > ' +
                    '<a href="#" id="' + index + '" class="shopping-item '+completed+'">' + item.name +
                    '<p class="todo-count"><strong class="ul-li-aside">' +
                    item.quantity + '</strong></p></a>';
            });
            $('#shoppingListItems').append($(html));
            $('#shoppingListItems').trigger('create');
            $('#shoppingListItems').listview().listview('refresh');

        } else {
            localStorage.setItem(v, []);
        }
        localStorage.setItem("currentList", v);

    }
    $.mobile.changePage("#shoppingListPage");

}
function clearStorage() {
    localStorage.clear();
    getShoppingLists();
}
function initShoppingItems() {
     shoppingItems = JSON.parse(localStorage.getItem("shoppingItems"));
    if (!shoppingItems)
        localStorage.setItem("shoppingItems", JSON.stringify(items));
}
function getShoppingItems() {
    $('#shoppingItems').empty();
    if (shoppingItems) {
        var html = '';
        $.each(shoppingItems, function (index, item) {
            html += '<li><a href="#"  onclick="setSelectedItem(' + index + ')">'
                + item + '</a></li>';
        });

        $('#shoppingItems').append($(html));
        $('#shoppingItems').trigger('create');
        $('#shoppingItems').listview().listview('refresh');
    } else {
        initShoppingItems();
        getShoppingItems();
    }
}

function setSelectedItem(index) {
    var item = shoppingItems[index];
    $("#itemFilters").val(item);
    $("#cShoppingItems").collapsible('collapse');
}
function getShoppingLists() {
    $('#shoppingLists').empty();
     shoppingLists = JSON.parse(localStorage.getItem("shoppingLists"));
    if (shoppingLists) {
        var sortedList = shoppingLists.sort(sortList).reverse();
        var html = '';
        $.each(sortedList, function (index, item) {
            html += '<li><a href="#"  onclick="getList(' + index + ')">' + item.name +
                '<p><strong class="ul-li-aside">' +
                new Date(item.dateCreated).toDateString() + '</strong></p></a>' +
                '<a href="#confirmconfirm">Delete</a></li>';
        });

        $('#shoppingLists').append($(html));
        $('#shoppingLists').trigger('create');
            $('#shoppingLists').listview().listview('refresh');
    }
}

function sortList(a, b) {
    return a.dateCreated - b.dateCreated;
}
function addNewList(list) {
    if(!list)
        return false;
    var existingLists = localStorage.getItem("shoppingLists");
    if (!existingLists) {
        var lists = [];
        lists.push(list);
        localStorage.setItem("shoppingLists", JSON.stringify(lists));
    } else {
        existingLists = JSON.parse(existingLists);
        existingLists.push(list);
        if (existingLists.length > 10) {
            alert("You cannot have more than 10 Lists at a time.");
            return false;
        }
        localStorage.removeItem("shoppingLists");
        localStorage.setItem("shoppingLists", JSON.stringify(existingLists));
    }
    return true;
};

     

